package com.example.cronometrogame

import android.content.Context
import android.os.Bundle
import android.os.SystemClock
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.random.Random
import kotlin.time.Duration.Companion.seconds

// Clase principal de la aplicación
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Muestra la primera pantalla del juego
        setContent {
            MaterialTheme {
                PantallaBienvenida(this)
            }
        }
    }
}

// Clase para guardar los datos de cada jugador en el ranking
data class JugadorRanking(
    val nombre: String,
    val tiempo: Long
)

@Composable
fun PantallaBienvenida(context: Context) {

    // Guarda el nombre que escribe el jugador
    var nombreJugador by remember { mutableStateOf("") }

    // Controla cuándo pasar a la pantalla del juego
    var empezarJuego by remember { mutableStateOf(false) }

    // Si el jugador ya presionó comenzar, entra al juego
    if (empezarJuego) {

        JuegoScreen(context, nombreJugador)

    } else {

        // Fondo degradado para que la pantalla se vea más gamer
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF1A237E),
                            Color(0xFF512DA8),
                            Color(0xFF7B1FA2)
                        )
                    )
                )
        ) {

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),

                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {

                // Título principal
                Text(
                    text = "🎮 CRONÓMETRO GAME",
                    fontSize = 34.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Pequeña descripción del juego
                Text(
                    text = "Adivina el número secreto antes de perder tus intentos",
                    fontSize = 18.sp,
                    color = Color.White
                )

                Spacer(modifier = Modifier.height(40.dp))

                // Tarjeta donde el usuario escribe su nombre
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = Color.White
                    ),

                    shape = RoundedCornerShape(20.dp)
                ) {

                    Column(
                        modifier = Modifier.padding(20.dp)
                    ) {

                        // Campo para ingresar el nombre
                        OutlinedTextField(
                            value = nombreJugador,

                            onValueChange = {
                                nombreJugador = it
                            },

                            label = {
                                Text("Nombre del jugador")
                            },

                            leadingIcon = {
                                Icon(
                                    Icons.Default.Person,
                                    contentDescription = null
                                )
                            },

                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        // Botón para iniciar el juego
                        Button(
                            onClick = {

                                // Solo permite entrar si escribió un nombre
                                if (nombreJugador.isNotEmpty()) {
                                    empezarJuego = true
                                }
                            },

                            modifier = Modifier.fillMaxWidth(),

                            shape = RoundedCornerShape(14.dp)
                        ) {

                            Text("Comenzar Juego")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun JuegoScreen(context: Context, nombreJugador: String) {

    // Número aleatorio que el jugador debe adivinar
    var numeroSecreto by remember {
        mutableIntStateOf(Random.nextInt(1, 101))
    }

    // Número que escribe el usuario
    var numeroUsuario by remember {
        mutableStateOf("")
    }

    // Mensajes de pistas, errores o victoria
    var mensaje by remember {
        mutableStateOf("")
    }

    // Intentos disponibles
    var intentos by remember {
        mutableIntStateOf(3)
    }

    // Tiempo transcurrido
    var tiempo by remember {
        mutableLongStateOf(0L)
    }

    // Momento exacto en que inició el juego
    var inicioTiempo by remember {
        mutableLongStateOf(SystemClock.elapsedRealtime())
    }

    // Controla si el juego terminó
    var juegoTerminado by remember {
        mutableStateOf(false)
    }

    // Muestra u oculta el ranking
    var mostrarRanking by remember {
        mutableStateOf(false)
    }

    // Obtiene el mejor tiempo guardado
    var mejorTiempo by remember {
        mutableStateOf(obtenerMejorTiempo(context))
    }

    // Obtiene el jugador con el récord
    var mejorJugador by remember {
        mutableStateOf(obtenerMejorJugador(context))
    }

    // Lista completa del ranking
    val ranking = obtenerRanking(context)

    // Cronómetro del juego
    LaunchedEffect(juegoTerminado) {

        // El tiempo sigue avanzando mientras el juego esté activo
        while (!juegoTerminado) {

            tiempo =
                (SystemClock.elapsedRealtime() - inicioTiempo) / 1000

            delay(1.seconds)
        }
    }

    // Fondo principal del juego
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF0F2027),
                        Color(0xFF203A43),
                        Color(0xFF2C5364)
                    )
                )
            )
    ) {

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp)
        ) {

            // Saludo personalizado
            Text(
                text = "👋 Bienvenido $nombreJugador",

                fontSize = 28.sp,

                fontWeight = FontWeight.Bold,

                color = Color.White
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Tarjeta con información importante del juego
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFF1E1E1E)
                ),

                shape = RoundedCornerShape(20.dp),

                modifier = Modifier.fillMaxWidth()
            ) {

                Column(
                    modifier = Modifier.padding(20.dp)
                ) {

                    // Tiempo actual
                    Text(
                        text = "⏱ Tiempo: ${tiempo}s",

                        color = Color.White,

                        fontSize = 20.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Récord actual
                    Text(
                        text = if (mejorTiempo != null) {
                            "🏆 Récord: ${mejorTiempo}s - $mejorJugador"
                        } else {
                            "🏆 Aún no hay récord"
                        },

                        color = Color.Yellow,

                        fontSize = 18.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Intentos restantes
                    Text(
                        text = "❤️ Intentos: $intentos",

                        color = Color.Red,

                        fontSize = 18.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Campo donde el jugador escribe el número
            OutlinedTextField(

                value = numeroUsuario,

                onValueChange = {

                    // Solo deja escribir números
                    numeroUsuario =
                        it.filter { c -> c.isDigit() }
                },

                label = {
                    Text("Ingresa un número del 1 al 100")
                },

                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Number
                ),

                enabled = !juegoTerminado,

                modifier = Modifier.fillMaxWidth(),

                shape = RoundedCornerShape(18.dp),
                colors = OutlinedTextFieldDefaults.colors(

                    // Texto del input
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,

                    // Texto del label
                    focusedLabelColor = Color.White,
                    unfocusedLabelColor = Color.LightGray,

                    // Bordes
                    focusedBorderColor = Color.Cyan,
                    unfocusedBorderColor = Color.Gray,

                    // Cursor
                    cursorColor = Color.White
                )
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Botón para comprobar el número
            Button(

                onClick = {

                    // Evita que el usuario deje el campo vacío
                    if (numeroUsuario.isEmpty()) {

                        mensaje =
                            "⚠ Debes ingresar un número"

                        return@Button
                    }

                    val num = numeroUsuario.toInt()

                    // Si adivina el número secreto
                    if (num == numeroSecreto) {

                        mensaje =
                            "🎉 ¡Ganaste en ${tiempo}s!"

                        juegoTerminado = true

                        // Guarda el resultado en el ranking
                        guardarRanking(
                            context,
                            nombreJugador,
                            tiempo
                        )

                        // Actualiza récord y jugador
                        mejorTiempo =
                            obtenerMejorTiempo(context)

                        mejorJugador =
                            obtenerMejorJugador(context)

                    } else {

                        // Resta un intento si falla
                        intentos--

                        // Da una pista al jugador
                        mensaje =
                            if (num < numeroSecreto) {
                                "🔼 El número es más grande"
                            } else {
                                "🔽 El número es más pequeño"
                            }

                        // Limpia el campo para el siguiente intento
                        numeroUsuario = ""
                    }

                    // Si ya no quedan intentos
                    if (intentos == 0 && !juegoTerminado) {

                        mensaje =
                            "❌ Perdiste. El número era $numeroSecreto"

                        juegoTerminado = true
                    }
                },

                enabled = !juegoTerminado,

                modifier = Modifier.fillMaxWidth(),

                shape = RoundedCornerShape(16.dp)
            ) {

                Text(
                    text = "VALIDAR",

                    fontSize = 18.sp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Botón para mostrar u ocultar ranking
            OutlinedButton(

                onClick = {
                    mostrarRanking = !mostrarRanking
                },

                modifier = Modifier.fillMaxWidth(),

                shape = RoundedCornerShape(16.dp)
            ) {

                Icon(
                    Icons.Default.Star,
                    contentDescription = null
                )

                Spacer(modifier = Modifier.width(8.dp))

                Text("Ver Ranking")
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Mensajes del juego
            Text(
                text = mensaje,

                color = Color.White,

                fontSize = 18.sp
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Ranking completo de jugadores
            if (mostrarRanking) {

                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = Color(0xFF1E1E1E)
                    ),

                    shape = RoundedCornerShape(20.dp),

                    modifier = Modifier.fillMaxWidth()
                ) {

                    Column(
                        modifier = Modifier.padding(16.dp)
                    ) {

                        Text(
                            text = "🏆 Ranking Global",

                            color = Color.Yellow,

                            fontSize = 22.sp,

                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        LazyColumn {

                            // Recorre cada jugador guardado
                            items(ranking) { jugador ->

                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 6.dp),

                                    colors = CardDefaults.cardColors(
                                        containerColor = Color(
                                            0xFF2C2C2C
                                        )
                                    )
                                ) {

                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(14.dp),

                                        horizontalArrangement =
                                            Arrangement.SpaceBetween
                                    ) {

                                        // Nombre del jugador
                                        Text(
                                            text = jugador.nombre,

                                            color = Color.White,

                                            fontSize = 18.sp
                                        )

                                        // Tiempo obtenido
                                        Text(
                                            text =
                                                "${jugador.tiempo}s",

                                            color = Color.Green,

                                            fontSize = 18.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Botón para reiniciar la partida
            if (juegoTerminado) {

                Button(

                    onClick = {

                        // Genera un nuevo número secreto
                        numeroSecreto =
                            Random.nextInt(1, 101)

                        // Reinicia variables
                        intentos = 3
                        mensaje = ""
                        numeroUsuario = ""
                        tiempo = 0

                        // Reinicia el cronómetro
                        inicioTiempo =
                            SystemClock.elapsedRealtime()

                        juegoTerminado = false
                    },

                    modifier = Modifier.fillMaxWidth(),

                    shape = RoundedCornerShape(16.dp)
                ) {

                    Text(
                        text = "JUGAR DE NUEVO",

                        fontSize = 18.sp
                    )
                }
            }
        }
    }
}

// Guarda los resultados y el récord
fun guardarRanking(
    context: Context,
    nombre: String,
    tiempo: Long
) {

    val prefs =
        context.getSharedPreferences(
            "ranking",
            Context.MODE_PRIVATE
        )

    // Obtiene el ranking actual
    val rankingActual =
        prefs.getString("lista_ranking", "") ?: ""

    // Nuevo dato que se agregará
    val nuevoDato = "$nombre,$tiempo;"

    // Guarda el nuevo jugador en la lista
    prefs.edit()
        .putString(
            "lista_ranking",
            rankingActual + nuevoDato
        )
        .apply()

    // Obtiene el mejor tiempo actual
    val mejorTiempo =
        prefs.getLong("mejor_tiempo", Long.MAX_VALUE)

    // Si el nuevo tiempo es mejor, actualiza el récord
    if (tiempo < mejorTiempo) {

        prefs.edit()
            .putLong("mejor_tiempo", tiempo)
            .putString("mejor_jugador", nombre)
            .apply()
    }
}

// Devuelve el mejor tiempo guardado
fun obtenerMejorTiempo(context: Context): Long? {

    val prefs =
        context.getSharedPreferences(
            "ranking",
            Context.MODE_PRIVATE
        )

    val mejor =
        prefs.getLong("mejor_tiempo", -1)

    // Si no hay récord, devuelve null
    return if (mejor != -1L) mejor else null
}

// Devuelve el nombre del jugador con récord
fun obtenerMejorJugador(context: Context): String {

    val prefs =
        context.getSharedPreferences(
            "ranking",
            Context.MODE_PRIVATE
        )

    return prefs.getString(
        "mejor_jugador",
        "Sin jugador"
    ) ?: "Sin jugador"
}

// Obtiene toda la lista del ranking
fun obtenerRanking(
    context: Context
): List<JugadorRanking> {

    val prefs =
        context.getSharedPreferences(
            "ranking",
            Context.MODE_PRIVATE
        )

    // Recupera los datos guardados
    val datos =
        prefs.getString("lista_ranking", "") ?: ""

    // Si no hay datos, devuelve lista vacía
    if (datos.isEmpty()) return emptyList()

    // Convierte el texto guardado en objetos JugadorRanking
    return datos.split(";")
        .filter { it.isNotEmpty() }
        .map {

            val partes = it.split(",")

            JugadorRanking(
                partes[0],
                partes[1].toLong()
            )
        }

        // Ordena el ranking por mejor tiempo
        .sortedBy { it.tiempo }
}